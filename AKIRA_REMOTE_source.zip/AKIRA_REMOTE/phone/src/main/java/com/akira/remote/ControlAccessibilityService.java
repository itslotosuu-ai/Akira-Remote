package com.akira.remote;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public class ControlAccessibilityService extends AccessibilityService {
    public static volatile ControlAccessibilityService INSTANCE;
    @Override public void onServiceConnected() { INSTANCE = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy() { if (INSTANCE == this) INSTANCE = null; super.onDestroy(); }

    public void tap(float nx, float ny) { gesture(nx, ny, nx, ny, 80); }
    public void swipe(float x1, float y1, float x2, float y2, long duration) {
        gesture(x1, y1, x2, y2, Math.max(100, Math.min(duration, 1200)));
    }
    private void gesture(float nx1, float ny1, float nx2, float ny2, long duration) {
        if (android.os.Build.VERSION.SDK_INT < 24) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x1 = clamp(nx1) * dm.widthPixels, y1 = clamp(ny1) * dm.heightPixels;
        float x2 = clamp(nx2) * dm.widthPixels, y2 = clamp(ny2) * dm.heightPixels;
        Path path = new Path(); path.moveTo(x1, y1); path.lineTo(x2, y2);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, duration);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }
    private float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
}
