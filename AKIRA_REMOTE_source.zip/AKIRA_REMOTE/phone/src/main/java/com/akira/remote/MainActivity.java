package com.akira.remote;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.net.wifi.WifiManager;
import android.content.Context;
import java.net.NetworkInterface;
import java.net.Inet4Address;
import java.util.Collections;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 41;
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF10131A);
        getWindow().setNavigationBarColor(0xFF10131A);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 48, 28, 28);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setBackgroundColor(0xFF10131A);
        TextView title = new TextView(this);
        title.setText("AKIRA  /  REMOTE");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("PHONE CONTROL • WEAR OS");
        subtitle.setTextColor(0xFF8D9AAF);
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, 12, 0, 32);
        layout.addView(subtitle, sp);
        status = new TextView(this);
        status.setText("Состояние: ожидание");
        status.setTextColor(0xFFE2E8F0);
        status.setTextSize(16);
        layout.addView(status);
        TextView ip = new TextView(this);
        ip.setText("IP телефона: " + getLocalIp());
        ip.setTextColor(0xFF4DD0E1);
        ip.setTextSize(18);
        LinearLayout.LayoutParams ipP = new LinearLayout.LayoutParams(-1, -2);
        ipP.setMargins(0, 18, 0, 28);
        layout.addView(ip, ipP);
        Button access = new Button(this);
        access.setText("Разрешить управление");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(access, new LinearLayout.LayoutParams(-1, -2));
        Button start = new Button(this);
        start.setText("Начать трансляцию");
        start.setOnClickListener(v -> {
            MediaProjectionManager m = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQUEST_CAPTURE);
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.setMargins(0, 12, 0, 0);
        layout.addView(start, bp);
        Button stop = new Button(this);
        stop.setText("Остановить трансляцию");
        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, CaptureService.class);
            i.setAction(CaptureService.ACTION_STOP);
            startService(i);
            status.setText("Состояние: остановлено");
        });
        layout.addView(stop, bp);
        TextView hint = new TextView(this);
        hint.setText("Телефон и часы должны быть в одной Wi‑Fi-сети. Введите IP выше в приложении на часах. Порт: 8765.");
        hint.setTextColor(0xFF9AA7B8);
        hint.setTextSize(13);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, 28, 0, 0);
        layout.addView(hint, hp);
        setContentView(layout);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQUEST_CAPTURE && result == RESULT_OK && data != null) {
            Intent i = new Intent(this, CaptureService.class);
            i.putExtra(CaptureService.EXTRA_RESULT_CODE, result);
            i.putExtra(CaptureService.EXTRA_DATA, data);
            startForegroundService(i);
            status.setText("Состояние: трансляция запущена");
        } else if (request == REQUEST_CAPTURE) status.setText("Состояние: разрешение не получено");
    }
    private String getLocalIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces()))
                for (java.net.InetAddress a : Collections.list(ni.getInetAddresses()))
                    if (!a.isLoopbackAddress() && a instanceof Inet4Address) return a.getHostAddress();
        } catch (Exception ignored) {}
        return "не найден — проверьте Wi-Fi";
    }
}
