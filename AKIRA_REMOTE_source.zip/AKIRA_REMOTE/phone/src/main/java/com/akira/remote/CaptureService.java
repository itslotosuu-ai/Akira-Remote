package com.akira.remote;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicBoolean;

public class CaptureService extends Service {
    public static final String EXTRA_RESULT_CODE="resultCode", EXTRA_DATA="resultData", ACTION_STOP="stop";
    private static final int PORT=8765, NOTIFICATION_ID=7;
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private RemoteServer server;
    private Handler handler;
    private int width, height, density;
    private final AtomicBoolean frameBusy = new AtomicBoolean(false);
    private final Runnable captureRunnable = new Runnable() {
        @Override public void run() {
            if (reader == null || server == null) return;
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image != null && frameBusy.compareAndSet(false, true)) {
                    Image.Plane plane = image.getPlanes()[0];
                    ByteBuffer buffer = plane.getBuffer();
                    int pixelStride = plane.getPixelStride(), rowStride = plane.getRowStride();
                    int rowPadding = rowStride - pixelStride * width;
                    Bitmap padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
                    padded.copyPixelsFromBuffer(buffer);
                    Bitmap frame = Bitmap.createBitmap(padded, 0, 0, width, height);
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    frame.compress(Bitmap.CompressFormat.JPEG, 48, out);
                    server.broadcast(out.toByteArray());
                    frame.recycle(); padded.recycle(); out.close();
                    frameBusy.set(false);
                }
            } catch (Exception ignored) { frameBusy.set(false); }
            finally { if (image != null) image.close(); }
            if (handler != null) handler.postDelayed(this, 180);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        NotificationChannel channel = new NotificationChannel("akira_remote", "AKIRA REMOTE", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        Notification notification = new Notification.Builder(this, "akira_remote")
            .setContentTitle("AKIRA REMOTE")
            .setContentText("Трансляция экрана активна")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true).build();
        startForeground(NOTIFICATION_ID, notification);
        if (projection == null && intent != null) startProjection(intent);
        return START_NOT_STICKY;
    }
    private void startProjection(Intent intent) {
        int result = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        Intent data = intent.getParcelableExtra(EXTRA_DATA);
        if (data == null || result != Activity.RESULT_OK) { stopSelf(); return; }
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(result, data);
        if (projection == null) { stopSelf(); return; }
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        width = dm.widthPixels; height = dm.heightPixels; density = dm.densityDpi;
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("AKIRA_REMOTE", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        server = new RemoteServer(new InetSocketAddress(PORT));
        server.start();
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopSelf(); }
        }, handler);
        handler.post(captureRunnable);
    }
    @Override public void onDestroy() {
        if (handler != null) handler.removeCallbacks(captureRunnable);
        try { if (server != null) server.stop(500); } catch (Exception ignored) {}
        if (display != null) display.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
    @Override public android.os.IBinder onBind(Intent intent) { return null; }

    private class RemoteServer extends WebSocketServer {
        private final CopyOnWriteArraySet<WebSocket> peers = new CopyOnWriteArraySet<>();
        RemoteServer(InetSocketAddress address) { super(address); setReuseAddr(true); }
        @Override public void onOpen(WebSocket conn, ClientHandshake handshake) { peers.add(conn); }
        @Override public void onClose(WebSocket conn, int code, String reason, boolean remote) { peers.remove(conn); }
        @Override public void onMessage(WebSocket conn, String message) {
            try {
                JSONObject j = new JSONObject(message);
                ControlAccessibilityService a = ControlAccessibilityService.INSTANCE;
                if (a == null) return;
                String type = j.optString("type");
                if ("tap".equals(type)) a.tap((float)j.optDouble("x"), (float)j.optDouble("y"));
                else if ("swipe".equals(type)) a.swipe((float)j.optDouble("x1"), (float)j.optDouble("y1"),
                    (float)j.optDouble("x2"), (float)j.optDouble("y2"), j.optLong("duration", 300));
            } catch (Exception ignored) {}
        }
        @Override public void onMessage(WebSocket conn, ByteBuffer message) {}
        @Override public void onError(WebSocket conn, Exception ex) {}
        @Override public void onStart() {}
        void broadcast(byte[] frame) {
            for (WebSocket peer : peers) if (peer.isOpen()) try { peer.send(frame); } catch (Exception ignored) {}
        }
    }
}
