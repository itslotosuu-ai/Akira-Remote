package com.akira.remotewatch;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.*;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONObject;
import java.net.URI;
import java.util.concurrent.atomic.AtomicReference;

public class WatchActivity extends Activity {
    private EditText address;
    private TextView status;
    private ImageView screen;
    private WebSocketClient client;
    private float downX, downY;
    private long downTime;
    private final AtomicReference<android.graphics.Bitmap> latest = new AtomicReference<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(8, 10, 8, 8);
        root.setBackgroundColor(Color.rgb(12,15,21));
        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(Color.WHITE);
        address.setHintTextColor(0xFF8895A7);
        address.setHint("IP телефона");
        address.setTextSize(12);
        root.addView(address, new LinearLayout.LayoutParams(-1, 42));
        Button connect = new Button(this);
        connect.setText("CONNECT");
        root.addView(connect, new LinearLayout.LayoutParams(-1, 42));
        status = new TextView(this);
        status.setText("Ожидание подключения");
        status.setTextColor(0xFF4DD0E1);
        status.setTextSize(10);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, 24));
        screen = new ImageView(this);
        screen.setBackgroundColor(Color.BLACK);
        screen.setScaleType(ImageView.ScaleType.FIT_XY);
        root.addView(screen, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        connect.setOnClickListener(v -> connect());
        screen.setOnTouchListener((v, e) -> {
            if (client == null || !client.isOpen() || screen.getWidth() == 0 || screen.getHeight() == 0) return true;
            float x = clamp(e.getX() / screen.getWidth()), y = clamp(e.getY() / screen.getHeight());
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX=x; downY=y; downTime=System.currentTimeMillis(); return true;
            }
            if (e.getAction() == MotionEvent.ACTION_UP) {
                try {
                    JSONObject j = new JSONObject();
                    if (Math.hypot(x-downX, y-downY) < 0.035) {
                        j.put("type","tap"); j.put("x",x); j.put("y",y);
                    } else {
                        j.put("type","swipe"); j.put("x1",downX); j.put("y1",downY);
                        j.put("x2",x); j.put("y2",y);
                        j.put("duration",Math.max(120, Math.min(900, System.currentTimeMillis()-downTime)));
                    }
                    client.send(j.toString());
                } catch (Exception ignored) {}
                return true;
            }
            return true;
        });
    }
    private float clamp(float x) { return Math.max(0f, Math.min(1f,x)); }
    private void connect() {
        String host = address.getText().toString().trim();
        if (host.isEmpty()) { status.setText("Введите IP телефона"); return; }
        try {
            if (client != null) client.close();
            client = new WebSocketClient(new URI("ws://" + host + ":8765")) {
                @Override public void onOpen(ServerHandshake h) { runOnUiThread(() -> status.setText("CONNECTED")); }
                @Override public void onMessage(String m) {}
                @Override public void onMessage(java.nio.ByteBuffer bytes) {
                    byte[] data = new byte[bytes.remaining()]; bytes.get(data);
                    android.graphics.Bitmap bmp = BitmapFactory.decodeByteArray(data,0,data.length);
                    if (bmp != null) runOnUiThread(() -> screen.setImageBitmap(bmp));
                }
                @Override public void onClose(int c, String r, boolean remote) { runOnUiThread(() -> status.setText("DISCONNECTED")); }
                @Override public void onError(Exception e) { runOnUiThread(() -> status.setText("Ошибка соединения")); }
            };
            client.connect();
            status.setText("Подключение…");
        } catch (Exception e) { status.setText("Неверный IP"); }
    }
    @Override protected void onDestroy() {
        if (client != null) client.close();
        super.onDestroy();
    }
}
